import Foundation
import simd

struct BrushStroke {
    enum StrokeMode: String, Codable {
        case paint
        case sculpt
    }
    
    var points: [SIMD3<Float>]
    var color: SIMD4<Float>
    var radius: Float
    var opacity: Float
    var mode: StrokeMode
    var id: UUID
    
    init(points: [SIMD3<Float>] = [], color: SIMD4<Float> = SIMD4<Float>(1, 1, 1, 1), radius: Float = 0.05, opacity: Float = 1.0, mode: StrokeMode = .paint) {
        self.id = UUID()
        self.points = points
        self.color = color
        self.radius = radius
        self.opacity = opacity
        self.mode = mode
    }
    
    mutating func addPoint(_ point: SIMD3<Float>) {
        points.append(point)
    }
}
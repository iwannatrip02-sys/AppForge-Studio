import Foundation
import simd

struct Camera {
    var position: SIMD3<Float> = SIMD3<Float>(0, 2, 5)
    var target: SIMD3<Float> = .zero
    var up: SIMD3<Float> = SIMD3<Float>(0, 1, 0)
    var fov: Float = 45.0
    var near: Float = 0.1
    var far: Float = 100.0
    var aspect: Float = 1.0
    
    var viewMatrix: simd_float4x4 {
        return simd_float4x4(lookAt: position, target: target, up: up)
    }
    
    var projectionMatrix: simd_float4x4 {
        return simd_float4x4(perspectiveWithFOV: fov, aspect: aspect, near: near, far: far)
    }
    
    mutating func updateAspect(_ newAspect: Float) {
        aspect = newAspect
    }
}

struct Scene3D {
    var camera: Camera
    var models: [Model3D]
    var strokes: [BrushStroke]
    var backgroundColor: SIMD4<Float> = SIMD4<Float>(0.1, 0.1, 0.12, 1.0)
    
    init() {
        camera = Camera()
        models = []
        strokes = []
    }
    
    mutating func addModel(_ model: Model3D) {
        models.append(model)
    }
    
    mutating func addStroke(_ stroke: BrushStroke) {
        strokes.append(stroke)
    }
}
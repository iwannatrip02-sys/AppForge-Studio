import SwiftUI
import MetalKit
import simd

struct MetalView: UIViewRepresentable {
    @Binding var scene: Scene3D
    @Binding var strokes: [BrushStroke]
    var onTouch3D: ((CGPoint) -> Void)?
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    func makeUIView(context: Context) -> MTKView {
        let mtkView = MTKView()
        mtkView.device = MTLCreateSystemDefaultDevice()
        mtkView.delegate = context.coordinator
        mtkView.clearColor = MTLClearColor(
            red: Double(scene.backgroundColor.x),
            green: Double(scene.backgroundColor.y),
            blue: Double(scene.backgroundColor.z),
            alpha: Double(scene.backgroundColor.w)
        )
        mtkView.enableSetNeedsDisplay = true
        mtkView.isPaused = false
        mtkView.framebufferOnly = false
        
        if let device = mtkView.device {
            context.coordinator.strokeRenderer = StrokeRenderer(device: device)
            context.coordinator.sceneRenderer = SceneRenderer(device: device)
            scene.camera.updateAspect(Float(mtkView.bounds.width / max(mtkView.bounds.height, 1)))
        }
        
        // Add tap gesture
        let tap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handleTap(_:)))
        mtkView.addGestureRecognizer(tap)
        
        return mtkView
    }
    
    func updateUIView(_ uiView: MTKView, context: Context) {
        context.coordinator.parent = self
        uiView.clearColor = MTLClearColor(
            red: Double(scene.backgroundColor.x),
            green: Double(scene.backgroundColor.y),
            blue: Double(scene.backgroundColor.z),
            alpha: Double(scene.backgroundColor.w)
        )
    }
    
    class Coordinator: NSObject, MTKViewDelegate {
        var parent: MetalView
        var strokeRenderer: StrokeRenderer?
        var sceneRenderer: SceneRenderer?
        
        init(_ parent: MetalView) {
            self.parent = parent
        }
        
        @objc func handleTap(_ gesture: UITapGestureRecognizer) {
            let location = gesture.location(in: gesture.view)
            parent.onTouch3D?(location)
        }
        
        func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
            parent.scene.camera.updateAspect(Float(size.width / max(size.height, 1)))
        }
        
        func draw(in view: MTKView) {
            guard let device = view.device,
                  let commandQueue = device.makeCommandQueue(),
                  let drawable = view.currentDrawable,
                  let renderPassDescriptor = view.currentRenderPassDescriptor else { return }
            
            let commandBuffer = commandQueue.makeCommandBuffer()!
            
            // Render 3D models
            sceneRenderer?.render(
                scene: parent.scene,
                commandBuffer: commandBuffer,
                renderPassDescriptor: renderPassDescriptor
            )
            
            // Render strokes on top
            strokeRenderer?.render(
                strokes: parent.strokes,
                commandBuffer: commandBuffer,
                renderPassDescriptor: renderPassDescriptor,
                viewMatrix: parent.scene.camera.viewMatrix,
                projectionMatrix: parent.scene.camera.projectionMatrix
            )
            
            commandBuffer.present(drawable)
            commandBuffer.commit()
        }
    }
}
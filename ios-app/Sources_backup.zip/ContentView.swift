import SwiftUI
import simd
import Metal

struct ContentView: View {
    @Binding var scene: Scene3D
    @Binding var strokes: [BrushStroke]
    var brushEngine: BrushEngine?
    var isPaintMode: Bool = false
    var satinRenderer: SatinRenderer?
    
    @State private var lastDrag: CGSize = .zero
    @State private var lastMagnification: CGFloat = 1.0
    @State private var currentStroke: BrushStroke?
    
    var body: some View {
        if let sr = satinRenderer, !isPaintMode {
            SatinRendererView(scene: $scene)
        } else {
            MetalView(scene: $scene, strokes: $strokes, onTouch3D: handleTouch)
        }
            .gesture(
                DragGesture(minimumDistance: isPaintMode ? 2 : 20)
                    .onChanged { value in
                        if !isPaintMode {
                            let delta = CGSize(width: value.translation.width - lastDrag.width, height: value.translation.height - lastDrag.height)
                            var cam = scene.camera
                            let dir = cam.target - cam.position; let dist = simd_length(dir)
                            let worldUp = SIMD3<Float>(0,1,0)
                            let right = simd_normalize(simd_cross(dir, worldUp))
                            let q1 = simd_quatf(angle: Float(delta.width)*0.005, axis: worldUp)
                            let q2 = simd_quatf(angle: Float(delta.height)*0.005, axis: right)
                            cam.position = cam.target - simd_normalize(q2*q1*dir) * dist
                            scene.camera = cam; lastDrag = value.translation
                        }
                    }
                    .onEnded { _ in
                        lastDrag = .zero
                        if isPaintMode, let s = currentStroke { strokes.append(s); currentStroke = nil }
                    }
            )
            .gesture(
                MagnificationGesture()
                    .onChanged { value in
                        if !isPaintMode {
                            let delta = value / lastMagnification
                            var cam = scene.camera; let dir = cam.target - cam.position
                            cam.position = cam.target - dir * (1.0 / Float(delta))
                            scene.camera = cam; lastMagnification = value
                        }
                    }
                    .onEnded { _ in lastMagnification = 1.0 }
            )
    }
    
    private func handleTouch(position: SIMD3<Float>, normal: SIMD3<Float>) {
        if isPaintMode {
            guard let engine = brushEngine else { return }
            let point = BrushPoint(position: position, normal: normal, pressure: 1.0, tilt: .zero)
            guard scene.models.indices.contains(0) else { return }
            engine.saveState(scene.models[0].meshes[0].vertices)
            if let device = MTLCreateSystemDefaultDevice() {
                let renderer = PaintRenderer(device: device)
                let cmdBuffer = renderer.commandQueue.makeCommandBuffer()!
                engine.paintStroke(at: point, on: &scene.models[0].meshes[0], renderer: renderer, cmdBuffer: cmdBuffer)
                cmdBuffer.commit()
                scene.models[0].meshes[0].uploadToGPU(device: device)
            }
            return
        }
        
        if isPaintMode {
            let point = BrushPoint(position: position, normal: normal, pressure: 1.0, tilt: .zero)
            if currentStroke == nil {
                currentStroke = BrushStroke(brushType: .round, color: SIMD4<Float>(0, 0, 1, 1), mode: .paint)
            }
            currentStroke?.addPoint(point)
        } else if let engine = brushEngine {
            let point = BrushPoint(position: position, normal: normal, pressure: 1.0, tilt: .zero)
            if scene.models.indices.contains(0) && scene.models[0].meshes.indices.contains(0) {
                engine.saveState(scene.models[0].meshes[0].vertices)
                engine.sculptStroke(at: point, on: &scene.models[0].meshes[0])
                if let device = MTLCreateSystemDefaultDevice() {
                    scene.models[0].meshes[0].uploadToGPU(device: device)
                }
            }
        }
    }
}

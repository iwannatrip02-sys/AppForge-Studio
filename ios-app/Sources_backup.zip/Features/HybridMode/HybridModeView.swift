import SwiftUI

struct HybridModeView: View {
    @ObservedObject var toolVM: ToolViewModel
    @Binding var scene: Scene3D
    @Binding var strokes: [BrushStroke]
    @State private var hybridSubMode: String = "Sculpt"
    
    let hybridTools: [(String, String)] = [
        ("Select", "cursor.rays"),
        ("Move", "arrow.up.and.down.and.arrow.left.and.right"),
        ("Sculpt", "hand.draw.fill"),
        ("Paint", "paintbrush.fill"),
        ("Extrude", "rectangle.3d.offshape")
    ]
    
    var body: some View {
        VStack(spacing: 12) {
            Text("Hibrido - \(toolVM.currentTool)")
                .font(.headline)
                .foregroundColor(.white)
            
            Picker("Modo", selection: $hybridSubMode) {
                Text("Escultura").tag("Sculpt")
                Text("CAD").tag("CAD")
                Text("Pintura").tag("Paint")
            }
            .pickerStyle(.segmented)
            .padding(.horizontal)
            
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
                ForEach(hybridTools, id: \.0) { name, icon in
                    Button(action: { toolVM.currentTool = name }) {
                        VStack(spacing: 4) {
                            Image(systemName: icon)
                                .font(.title3)
                            Text(name)
                                .font(.caption2)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(6)
                        .background(toolVM.currentTool == name ? Color.accentColor : Color.gray.opacity(0.3))
                        .foregroundColor(.white)
                        .cornerRadius(8)
                    }
                }
            }
        }
        .padding()
        .background(Color(.systemGray6).opacity(0.15))
        .cornerRadius(12)
    }
}
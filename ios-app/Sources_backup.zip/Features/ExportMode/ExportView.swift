import SwiftUI
import UniformTypeIdentifiers

struct ExportView: View {
    @ObservedObject var exportVM: ExportViewModel
    var exportService: ExportService
    @Binding var scene: Scene3D
    @Binding var isPresented: Bool
    @State private var selectedFormat: ExportFormat = .obj
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Exportar Modelo")
                    .font(.title2)
                    .fontWeight(.semibold)
                
                Picker("Formato", selection: $selectedFormat) {
                    ForEach(ExportFormat.allCases, id: \.self) { format in
                        Text(format.rawValue).tag(format)
                    }
                }
                .pickerStyle(.segmented)
                .padding(.horizontal)
                
                if exportVM.isExporting {
                    ProgressView("Exportando...", value: exportVM.progress, total: 1.0)
                        .padding()
                    Button("Cancelar", action: { exportVM.cancelExport() })
                        .foregroundColor(.red)
                } else {
                    Button(action: {
                        let baseURL = FileManager.default.temporaryDirectory
                        exportVM.exportScene(service: exportService, models: scene.models, format: selectedFormat, to: baseURL)
                    }) {
                        Label("Exportar \(selectedFormat.rawValue)", systemImage: "square.and.arrow.up")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.accentColor)
                            .foregroundColor(.white)
                            .cornerRadius(12)
                    }
                    .disabled(scene.models.isEmpty)
                }
                
                Spacer()
            }
            .padding()
            .navigationBarItems(trailing: Button("Cerrar") { isPresented = false })
            .alert("Exportacion", isPresented: $exportVM.showAlert) {
                Button("OK", role: .cancel) { isPresented = false }
            } message: {
                Text(exportVM.alertMessage)
            }
        }
    }
}
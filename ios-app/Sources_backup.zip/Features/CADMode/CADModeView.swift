import SwiftUI

struct CADModeView: View {
    @ObservedObject var toolVM: ToolViewModel
    @Binding var scene: Scene3D
    
    let cadIcons: [String: String] = [
        "Select": "cursor.rays",
        "Move": "arrow.up.and.down.and.arrow.left.and.right",
        "Rotate": "rotate.3d",
        "Scale": "scale.3d",
        "Extrude": "rectangle.3d.offshape",
        "LoopCut": "square.dashed.inset.filled",
        "Bevel": "hexagon.fill",
        "Boolean": "square.3d.layers.3d",
        "Measure": "ruler.fill"
    ]
    
    var body: some View {
        VStack(spacing: 12) {
            Text("CAD - \(toolVM.currentTool)")
                .font(.headline)
                .foregroundColor(.white)
            
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
                ForEach(toolVM.toolsForCurrentMode, id: \.self) { tool in
                    Button(action: { toolVM.currentTool = tool }) {
                        VStack(spacing: 4) {
                            Image(systemName: cadIcons[tool] ?? "cube.transparent")
                                .font(.title3)
                            Text(tool)
                                .font(.caption2)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(6)
                        .background(toolVM.currentTool == tool ? Color.accentColor : Color.gray.opacity(0.3))
                        .foregroundColor(.white)
                        .cornerRadius(8)
                    }
                }
            }
            
            Toggle("Snap", isOn: $toolVM.snapEnabled)
                .font(.caption)
                .foregroundColor(.white)
                .padding(.horizontal)
        }
        .padding()
        .background(Color(.systemGray6).opacity(0.15))
        .cornerRadius(12)
    }
}
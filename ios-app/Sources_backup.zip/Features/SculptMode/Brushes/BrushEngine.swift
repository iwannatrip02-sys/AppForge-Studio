import Foundation
import Metal
import simd

enum DeformType: String, CaseIterable {
    case round, flat, inflate, pinch, smooth, crease, grab, clay, airbrush
}

class BrushEngine {
    var undoStack: [[Model3D]] = []
    var redoStack: [[Model3D]] = []
    let maxUndo: Int = 50
    var symmetry: Bool = true
    var symmetryAxis: Int = 0
    
    func pushUndo(_ models: [Model3D]) {
        undoStack.append(models)
        if undoStack.count > maxUndo {
            undoStack.removeFirst()
        }
        redoStack.removeAll()
    }
    
    func popUndo() -> [Model3D]? {
        guard let last = undoStack.popLast() else { return nil }
        return last
    }
    
    func pushRedo(_ models: [Model3D]) {
        redoStack.append(models)
    }
    
    func popRedo() -> [Model3D]? {
        return redoStack.popLast()
    }
    
    func applyDeformation(to model: inout Model3D, at point: SIMD3<Float>, radius: Float, strength: Float, type: DeformType) {
        guard let vertexBuffer = model.vertexBuffer else { return }
        
        let ptr = vertexBuffer.contents().bindMemory(to: Float.self, capacity: vertexBuffer.length / MemoryLayout<Float>.stride)
        let vertexCount = model.vertexCount
        
        for i in 0..<vertexCount {
            let base = i * 8
            let px = ptr[base]
            let py = ptr[base + 1]
            let pz = ptr[base + 2]
            let nx = ptr[base + 3]
            let ny = ptr[base + 4]
            let nz = ptr[base + 5]
            
            let pos = SIMD3<Float>(px, py, pz)
            let normal = SIMD3<Float>(nx, ny, nz)
            let dist = simd_distance(pos, point)
            
            if dist < radius {
                let falloff = 1.0 - (dist / radius)
                let f2 = falloff * falloff
                let f3 = f2 * falloff
                let delta = strength * f3
                
                var newPos = pos
                
                switch type {
                case .round:
                    let dir = simd_normalize(normal)
                    newPos += dir * delta * radius
                case .flat:
                    let avgNormal = averageNormal(at: pos, vertices: ptr, count: vertexCount, radius: radius)
                    newPos += avgNormal * delta * radius
                case .inflate:
                    let dir = simd_normalize(pos)
                    newPos += dir * delta * radius
                case .pinch:
                    let dir = point - pos
                    let dLen = simd_length(dir)
                    if dLen > 0.001 {
                        newPos += (dir / dLen) * delta * radius
                    }
                case .smooth:
                    let avgPos = averagePosition(at: pos, vertices: ptr, count: vertexCount, radius: radius)
                    newPos = simd_mix(pos, avgPos, delta)
                case .crease:
                    let dir = -simd_normalize(normal)
                    newPos += dir * delta * radius
                case .grab:
                    let grabVec = point - pos
                    let gLen = simd_length(grabVec)
                    if gLen > 0.001 {
                        newPos += (grabVec / gLen) * delta * radius * 2.0
                    }
                case .clay:
                    newPos.y += delta * radius * 2.0
                case .airbrush:
                    let randX = Float.random(in: -0.001...0.001) * delta * radius * 50.0
                    let randY = Float.random(in: -0.001...0.001) * delta * radius * 50.0
                    let randZ = Float.random(in: -0.001...0.001) * delta * radius * 50.0
                    newPos += SIMD3<Float>(randX, randY, randZ)
                }
                
                ptr[base] = newPos.x
                ptr[base + 1] = newPos.y
                ptr[base + 2] = newPos.z
            }
        }
    }
    
    private func averagePosition(at pos: SIMD3<Float>, vertices: UnsafeMutablePointer<Float>, count: Int, radius: Float) -> SIMD3<Float> {
        var sum = SIMD3<Float>.zero
        var weight: Float = 0
        for j in 0..<count {
            let b = j * 8
            let v = SIMD3<Float>(vertices[b], vertices[b+1], vertices[b+2])
            let d = simd_distance(v, pos)
            if d < radius && d > 0.001 {
                let w = 1.0 - (d / radius)
                sum += v * w
                weight += w
            }
        }
        return weight > 0.001 ? sum / weight : pos
    }
    
    private func averageNormal(at pos: SIMD3<Float>, vertices: UnsafeMutablePointer<Float>, count: Int, radius: Float) -> SIMD3<Float> {
        var sum = SIMD3<Float>.zero
        var weight: Float = 0
        for j in 0..<count {
            let b = j * 8
            let v = SIMD3<Float>(vertices[b], vertices[b+1], vertices[b+2])
            let n = SIMD3<Float>(vertices[b+3], vertices[b+4], vertices[b+5])
            let d = simd_distance(v, pos)
            if d < radius && d > 0.001 {
                let w = 1.0 - (d / radius)
                sum += n * w
                weight += w
            }
        }
        return weight > 0.001 ? simd_normalize(sum / weight) : SIMD3<Float>(0, 1, 0)
    }
}
import SwiftUI

struct SculptModeView: View {
    @ObservedObject var toolVM: ToolViewModel
    @Binding var scene: Scene3D
    @Binding var strokes: [BrushStroke]
    
    let brushIcons: [String: String] = [
        "Round": "circle",
        "Flat": "square.fill",
        "Inflate": "arrow.up.heart.fill",
        "Pinch": "hand.pinch.fill",
        "Smooth": "circle.hexagongrid.fill",
        "Crease": "line.diagonal",
        "Grab": "hand.draw.fill",
        "Clay": "drop.fill",
        "Airbrush": "fanblades.fill"
    ]
    
    var body: some View {
        VStack(spacing: 12) {
            Text("Escultura - \(toolVM.currentTool)")
                .font(.headline)
                .foregroundColor(.white)
            
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
                ForEach(toolVM.toolsForCurrentMode, id: \.self) { tool in
                    Button(action: { toolVM.currentTool = tool }) {
                        VStack(spacing: 4) {
                            Image(systemName: brushIcons[tool] ?? "pencil.tip")
                                .font(.title2)
                            Text(tool)
                                .font(.caption2)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(8)
                        .background(toolVM.currentTool == tool ? Color.accentColor : Color.gray.opacity(0.3))
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                }
            }
            
            VStack(spacing: 6) {
                HStack {
                    Text("Tamano: \(String(format: "%.2f", toolVM.brushSize))")
                        .font(.caption)
                        .foregroundColor(.white)
                    Slider(value: $toolVM.brushSize, in: 0.01...0.5)
                        .tint(.accentColor)
                }
                HStack {
                    Text("Fuerza: \(String(format: "%.1f", toolVM.brushStrength))")
                        .font(.caption)
                        .foregroundColor(.white)
                    Slider(value: $toolVM.brushStrength, in: 0.1...1.0)
                        .tint(.accentColor)
                }
                Toggle("Simetria", isOn: $toolVM.symmetry)
                    .font(.caption)
                    .foregroundColor(.white)
            }
            .padding(.horizontal)
        }
        .padding()
        .background(Color(.systemGray6).opacity(0.15))
        .cornerRadius(12)
    }
}
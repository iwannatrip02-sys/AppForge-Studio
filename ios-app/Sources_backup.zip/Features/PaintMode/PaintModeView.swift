import SwiftUI

struct PaintModeView: View {
    @ObservedObject var toolVM: ToolViewModel
    @Binding var scene: Scene3D
    @Binding var strokes: [BrushStroke]
    @State private var selectedColor: Color = .white
    
    let paintTools: [(String, String)] = [
        ("Brush", "paintbrush.fill"),
        ("Fill", "paintbucket.fill"),
        ("Eyedropper", "eye.drop.fill"),
        ("Eraser", "eraser.fill")
    ]
    
    let presetColors: [Color] = [
        .red, .orange, .yellow, .green, .blue, .indigo, .purple, .white, .gray, .black
    ]
    
    var body: some View {
        VStack(spacing: 12) {
            Text("Pintura - \(toolVM.currentTool)")
                .font(.headline)
                .foregroundColor(.white)
            
            HStack(spacing: 8) {
                ForEach(paintTools, id: \.0) { name, icon in
                    Button(action: { toolVM.currentTool = name }) {
                        VStack(spacing: 2) {
                            Image(systemName: icon)
                                .font(.title3)
                            Text(name)
                                .font(.caption2)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(6)
                        .background(toolVM.currentTool == name ? Color.accentColor : Color.gray.opacity(0.3))
                        .foregroundColor(.white)
                        .cornerRadius(8)
                    }
                }
            }
            
            Text("Colores")
                .font(.caption)
                .foregroundColor(.white)
            
            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 5), spacing: 6) {
                ForEach(presetColors, id: \.self) { color in
                    Circle()
                        .fill(color)
                        .frame(width: 28, height: 28)
                        .overlay(
                            Circle()
                                .stroke(selectedColor == color ? Color.white : Color.clear, lineWidth: 2)
                        )
                        .onTapGesture {
                            selectedColor = color
                        }
                }
            }
            
            VStack(spacing: 6) {
                HStack {
                    Text("Tamano: \(String(format: "%.2f", toolVM.brushSize))")
                        .font(.caption)
                        .foregroundColor(.white)
                    Slider(value: $toolVM.brushSize, in: 0.01...0.5)
                        .tint(.accentColor)
                }
                HStack {
                    Text("Fuerza: \(String(format: "%.1f", toolVM.brushStrength))")
                        .font(.caption)
                        .foregroundColor(.white)
                    Slider(value: $toolVM.brushStrength, in: 0.1...1.0)
                        .tint(.accentColor)
                }
            }
            .padding(.horizontal)
        }
        .padding()
        .background(Color(.systemGray6).opacity(0.15))
        .cornerRadius(12)
    }
}
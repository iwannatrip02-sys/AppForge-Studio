import Foundation
import ModelIO
import MetalKit

class ExportService {
    let device: MTLDevice
    
    init(device: MTLDevice) {
        self.device = device
    }
    
    func exportToOBJ(models: [Model3D], to url: URL) -> Bool {
        let asset = createMDLAsset(from: models)
        let path = url.appendingPathExtension("obj")
        do {
            try asset.export(to: path)
            return true
        } catch {
            print("Export OBJ failed: \(error)")
            return false
        }
    }
    
    func exportToSTL(models: [Model3D], to url: URL) -> Bool {
        let asset = createMDLAsset(from: models)
        let path = url.appendingPathExtension("stl")
        do {
            try asset.export(to: path)
            return true
        } catch {
            print("Export STL failed: \(error)")
            return false
        }
    }
    
    private func createMDLAsset(from models: [Model3D]) -> MDLAsset {
        let asset = MDLAsset()
        let mtkMeshBufferAllocator = MTKMeshBufferAllocator(device: device)
        
        for model in models {
            guard let vertexBuffer = model.vertexBuffer,
                  let indexBuffer = model.indexBuffer else { continue }
            
            let vertexData = Data(bytes: vertexBuffer.contents(), count: vertexBuffer.length)
            let indexData = Data(bytes: indexBuffer.contents(), count: indexBuffer.length)
            
            let vertexFormat = MDLVertexFormat.float4
            let vertexDescriptor = MDLVertexDescriptor()
            vertexDescriptor.attributes[0] = MDLVertexAttribute(name: MDLVertexAttributePosition, format: vertexFormat, offset: 0, bufferIndex: 0)
            vertexDescriptor.attributes[1] = MDLVertexAttribute(name: MDLVertexAttributeNormal, format: .float3, offset: MemoryLayout<SIMD4<Float>>.stride, bufferIndex: 0)
            vertexDescriptor.layouts[0] = MDLVertexBufferLayout(stride: MemoryLayout<SIMD4<Float>>.stride + MemoryLayout<SIMD3<Float>>.stride + MemoryLayout<SIMD2<Float>>.stride + MemoryLayout<SIMD4<Float>>.stride)
            
            let meshBuffer = mtkMeshBufferAllocator.newBuffer(with: vertexData, type: .vertex)
            let indexBufferMDL = mtkMeshBufferAllocator.newBuffer(with: indexData, type: .index)
            
            let submesh = MDLSubmesh(indexBuffer: indexBufferMDL, indexCount: model.indexCount, indexType: .uInt16, geometryType: .triangles, material: nil)
            
            if let mesh = MDLMesh(vertexBuffer: meshBuffer, vertexCount: model.vertexCount, descriptor: vertexDescriptor, submeshes: [submesh]) {
                let transform = MDLTransform()
                transform.matrix = model.transform
                mesh.transform = transform
                asset.add(mesh)
            }
        }
        
        return asset
    }
}
import Foundation
import Metal

enum PrimitiveType: String, CaseIterable {
    case box, sphere, cylinder, plane, torus
}

class ModelLoadService {
    let device: MTLDevice
    
    init(device: MTLDevice) {
        self.device = device
    }
    
    func createPrimitive(type: PrimitiveType) -> Model3D {
        let (vertices, indices): ([Float], [UInt16]) = generateGeometry(type: type)
        let model = Model3D(name: type.rawValue.capitalized, vertices: vertices, indices: indices, device: device)
        return model
    }
    
    private func generateGeometry(type: PrimitiveType) -> ([Float], [UInt16]) {
        switch type {
        case .box: return generateBox()
        case .sphere: return generateSphere(slices: 16, stacks: 12)
        case .cylinder: return generateCylinder(segments: 24)
        case .plane: return generatePlane()
        case .torus: return generateTorus(ringSegments: 16, tubeSegments: 12)
        }
    }
    
    private func generateBox() -> ([Float], [UInt16]) {
        let verts: [Float] = [
            -0.5,-0.5, 0.5, 0,0,1, 0,0,   0.5,-0.5, 0.5, 0,0,1, 1,0,   0.5, 0.5, 0.5, 0,0,1, 1,1,  -0.5, 0.5, 0.5, 0,0,1, 0,1,
            -0.5, 0.5,-0.5, 0,0,-1, 0,0,  0.5, 0.5,-0.5, 0,0,-1, 1,0,   0.5,-0.5,-0.5, 0,0,-1, 1,1,  -0.5,-0.5,-0.5, 0,0,-1, 0,1,
            -0.5, 0.5, 0.5, 0,1,0, 0,0,   0.5, 0.5, 0.5, 0,1,0, 1,0,   0.5, 0.5,-0.5, 0,1,0, 1,1,  -0.5, 0.5,-0.5, 0,1,0, 0,1,
            -0.5,-0.5,-0.5, 0,-1,0, 0,0,  0.5,-0.5,-0.5, 0,-1,0, 1,0,   0.5,-0.5, 0.5, 0,-1,0, 1,1,  -0.5,-0.5, 0.5, 0,-1,0, 0,1,
            0.5,-0.5, 0.5, 1,0,0, 0,0,  0.5,-0.5,-0.5, 1,0,0, 1,0,  0.5, 0.5,-0.5, 1,0,0, 1,1,  0.5, 0.5, 0.5, 1,0,0, 0,1,
            -0.5,-0.5,-0.5, -1,0,0, 0,0, -0.5,-0.5, 0.5, -1,0,0, 1,0, -0.5, 0.5, 0.5, -1,0,0, 1,1, -0.5, 0.5,-0.5, -1,0,0, 0,1
        ]
        let idxs: [UInt16] = [
            0,1,2, 0,2,3, 4,5,6, 4,6,7, 8,9,10, 8,10,11,
            12,13,14, 12,14,15, 16,17,18, 16,18,19, 20,21,22, 20,22,23
        ]
        return (verts, idxs)
    }
    
    private func generateSphere(slices: Int, stacks: Int) -> ([Float], [UInt16]) {
        var verts: [Float] = []
        var idxs: [UInt16] = []
        for j in 0...stacks {
            let phi = Float.pi * Float(j) / Float(stacks)
            for i in 0...slices {
                let theta = 2.0 * Float.pi * Float(i) / Float(slices)
                let x = sin(phi) * cos(theta)
                let y = cos(phi)
                let z = sin(phi) * sin(theta)
                verts += [x*0.5, y*0.5, z*0.5, x, y, z, Float(i)/Float(slices), Float(j)/Float(stacks)]
            }
        }
        for j in 0..<stacks {
            for i in 0..<slices {
                let first = UInt16(j * (slices + 1) + i)
                let second = UInt16(first + UInt16(slices + 1))
                idxs += [first, second, first + 1, second, second + 1, first + 1]
            }
        }
        return (verts, idxs)
    }
    
    private func generateCylinder(segments: Int) -> ([Float], [UInt16]) {
        var verts: [Float] = []
        var idxs: [UInt16] = []
        let rad: Float = 0.5
        let halfH: Float = 0.5
        
        for i in 0...segments {
            let angle = 2.0 * Float.pi * Float(i) / Float(segments)
            let cx = cos(angle) * rad
            let cz = sin(angle) * rad
            let nx = cos(angle)
            let nz = sin(angle)
            verts += [cx, -halfH, cz, nx, 0, nz, Float(i)/Float(segments), 0]
            verts += [cx, halfH, cz, nx, 0, nz, Float(i)/Float(segments), 1]
        }
        let centerTop = UInt16(verts.count / 8)
        verts += [0, halfH, 0, 0, 1, 0, 0.5, 0.5]
        let centerBot = UInt16(verts.count / 8)
        verts += [0, -halfH, 0, 0, -1, 0, 0.5, 0.5]
        
        for i in 0..<segments {
            let a = UInt16(i * 2)
            let b = UInt16(i * 2 + 1)
            let c = UInt16((i + 1) % segments * 2)
            let d = UInt16((i + 1) % segments * 2 + 1)
            idxs += [a, c, b, b, c, d]
            idxs += [centerTop, b, d, centerBot, c, a]
        }
        
        return (verts, idxs)
    }
    
    private func generatePlane() -> ([Float], [UInt16]) {
        let verts: [Float] = [
            -0.5, -0.5, 0, 0, 0, 1, 0, 0,
             0.5, -0.5, 0, 0, 0, 1, 1, 0,
             0.5,  0.5, 0, 0, 0, 1, 1, 1,
            -0.5,  0.5, 0, 0, 0, 1, 0, 1
        ]
        let idxs: [UInt16] = [0, 1, 2, 0, 2, 3]
        return (verts, idxs)
    }
    
    private func generateTorus(ringSegments: Int, tubeSegments: Int) -> ([Float], [UInt16]) {
        var verts: [Float] = []
        var idxs: [UInt16] = []
        let R: Float = 0.4
        let r: Float = 0.15
        
        for i in 0...ringSegments {
            let u = 2.0 * Float.pi * Float(i) / Float(ringSegments)
            for j in 0...tubeSegments {
                let v = 2.0 * Float.pi * Float(j) / Float(tubeSegments)
                let cx = (R + r * cos(v)) * cos(u)
                let cy = r * sin(v)
                let cz = (R + r * cos(v)) * sin(u)
                let nx = cos(v) * cos(u)
                let ny = sin(v)
                let nz = cos(v) * sin(u)
                verts += [cx, cy, cz, nx, ny, nz, Float(i)/Float(ringSegments), Float(j)/Float(tubeSegments)]
            }
        }
        for i in 0..<ringSegments {
            for j in 0..<tubeSegments {
                let a = UInt16(i * (tubeSegments + 1) + j)
                let b = UInt16(a + 1)
                let c = UInt16((i + 1) * (tubeSegments + 1) + j)
                let d = UInt16(c + 1)
                idxs += [a, c, b, b, c, d]
            }
        }
        return (verts, idxs)
    }
}
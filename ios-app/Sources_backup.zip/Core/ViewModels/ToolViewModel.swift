import SwiftUI
import Combine

class ToolViewModel: ObservableObject {
    @Published var currentMode: AppMode = .Sculpt
    @Published var currentTool: String = "Round"
    @Published var brushSize: Float = 0.05
    @Published var brushStrength: Float = 0.5
    @Published var symmetry: Bool = true
    @Published var snapEnabled: Bool = false
    @Published var transformSpace: String = "local"

    var toolsForCurrentMode: [String] {
        switch currentMode {
        case .CAD:
            return ["Select", "Move", "Rotate", "Scale", "Extrude", "LoopCut", "Bevel", "Boolean", "Measure"]
        case .Sculpt:
            return ["Round", "Flat", "Inflate", "Pinch", "Smooth", "Crease", "Grab", "Clay", "Airbrush"]
        case .Paint:
            return ["Brush", "Fill", "Eyedropper", "Eraser"]
        case .Hybrid:
            return ["Select", "Move", "Sculpt", "Paint", "Extrude"]
        case .Render:
            return ["Orbit", "Pan", "Zoom", "Wireframe", "XRay"]
        }
    }

    var brushPresets: [[String: Any]] {
        return [
            ["name": "Fine", "size": 0.02, "strength": 0.8],
            ["name": "Medium", "size": 0.05, "strength": 0.5],
            ["name": "Large", "size": 0.15, "strength": 0.3]
        ]
    }

    func selectPreset(_ preset: [String: Any]) {
        if let size = preset["size"] as? Float {
            brushSize = size
        }
        if let strength = preset["strength"] as? Float {
            brushStrength = strength
        }
    }

    // MARK: - CAD Tool Support
    @Published var selectedCADTool: CADTool = .select
    @Published var gridSnapEnabled: Bool = false
    @Published var measurementDistance: Float = 0
    @Published var measurementArea: Float = 0
    @Published var measurementVolume: Float = 0

    private lazy var extrusionEngine = ExtrusionEngine()
    private lazy var bevelEngine = BevelEngine()
    private lazy var booleanEngine = BooleanEngine()
    private lazy var loopCutEngine = LoopCutEngine()
    private lazy var measureEngine = MeasureEngine()

    func executeCADTool(mesh: inout Mesh) {
        switch selectedCADTool {
        case .extrude:
            let faceIndices = stride(from: 0, to: min(mesh.indices.count, 9), by: 3).map { Int(mesh.indices[$0]) }
            guard !faceIndices.isEmpty else { return }
            mesh = extrusionEngine.extrude(mesh: &mesh, faceIndices: faceIndices, direction: SIMD3<Float>(0, 0, 1), distance: 0.1)
        case .loopCut:
            if mesh.indices.count >= 6 {
                let i0 = Int(mesh.indices[0]), i1 = Int(mesh.indices[1])
                _ = loopCutEngine.loopCut(mesh: &mesh, edgeLoop: [(i0, i1)])
            }
        case .bevel:
            if mesh.indices.count >= 6 {
                let i0 = Int(mesh.indices[0]), i1 = Int(mesh.indices[1])
                _ = bevelEngine.bevel(mesh: &mesh, edgeIndices: [(i0, i1)], bevelSize: 0.05, segments: 2)
            }
        case .boolean:
            let copy = mesh
            mesh = booleanEngine.booleanUnion(a: mesh, b: copy)
        case .measure:
            measurementArea = measureEngine.measureArea(mesh: mesh)
            measurementVolume = measureEngine.measureVolume(mesh: mesh)
            measurementDistance = measureEngine.measureDistance(p1: .zero, p2: SIMD3<Float>(1, 0, 0))
        default:
            break
        }
    }
}

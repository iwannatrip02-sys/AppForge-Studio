import SwiftUI
import Combine

enum ExportFormat: String, CaseIterable {
    case obj = "OBJ"
    case stl = "STL"
}

class ExportViewModel: ObservableObject {
    @Published var isExporting: Bool = false
    @Published var progress: Float = 0.0
    @Published var showAlert: Bool = false
    @Published var alertMessage: String = ""
    
    private var timer: Timer?
    
    func exportScene(service: ExportService, models: [Model3D], format: ExportFormat, to baseURL: URL) {
        isExporting = true
        progress = 0.0
        
        timer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { [weak self] t in
            guard let self = self else { return }
            self.progress += 0.03
            if self.progress >= 1.0 {
                t.invalidate()
                self.timer = nil
                let fileName = "model.\(format.rawValue.lowercased())"
                let fileURL = baseURL.appendingPathComponent(fileName)
                var success = false
                switch format {
                case .obj:
                    success = service.exportToOBJ(models: models, to: fileURL)
                case .stl:
                    success = service.exportToSTL(models: models, to: fileURL)
                }
                self.isExporting = false
                self.progress = 1.0
                if success {
                    self.alertMessage = "Exportado exitosamente a \n\(fileURL.path)"
                } else {
                    self.alertMessage = "Error al exportar el archivo"
                }
                self.showAlert = true
            }
        }
    }
    
    func cancelExport() {
        timer?.invalidate()
        timer = nil
        isExporting = false
        progress = 0.0
    }
}
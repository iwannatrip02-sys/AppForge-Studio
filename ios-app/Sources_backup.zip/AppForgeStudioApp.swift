import SwiftUI
import Metal
import MetalKit

@main
struct AppForgeStudioApp: App {
    @StateObject private var appState = AppState()
    @StateObject private var toolVM = ToolViewModel()
    @StateObject private var exportVM = ExportViewModel()
    @State private var exportService: ExportService? = nil
    @State private var modelLoadService: ModelLoadService? = nil
    @State private var satinRenderer: SatinRenderer?
    
    init() {
        if let device = MTLCreateSystemDefaultDevice() {
            _exportService = State(initialValue: ExportService(device: device))
            _modelLoadService = State(initialValue: ModelLoadService(device: device))
            let mtkView = MTKView()
            mtkView.device = device
            let sRenderer = SatinRenderer(mtkView: mtkView)
            sRenderer.setup()
            _satinRenderer = State(initialValue: sRenderer)
        }
    }
    
    var body: some Scene {
        WindowGroup {
            ZStack {
                Color.black.edgesIgnoringSafeArea(.all)
                
                VStack(spacing: 0) {
                    // Top navigation
                    HStack {
                        Text("AppForge Studio")
                            .font(.headline)
                            .foregroundColor(.white)
                        Spacer()
                        HStack(spacing: 2) {
                            ForEach(AppMode.allCases, id: \.rawValue) { mode in
                                Button(action: {
                                    appState.selectedMode = mode
                                    toolVM.currentMode = mode
                                    if let first = toolVM.toolsForCurrentMode.first {
                                        toolVM.currentTool = first
                                    }
                                }) {
                                    Text(mode.rawValue)
                                        .font(.system(size: 12, weight: appState.selectedMode == mode ? .bold : .regular))
                                        .padding(.horizontal, 12)
                                        .padding(.vertical, 6)
                                        .background(appState.selectedMode == mode ? Color.accentColor : Color.gray.opacity(0.3))
                                        .foregroundColor(.white)
                                        .cornerRadius(8)
                                }
                            }
                        }
                        Spacer()
                        Button(action: { appState.showExport = true }) {
                            Image(systemName: "square.and.arrow.up")
                                .foregroundColor(.white)
                        }
                        .disabled(appState.canvasVM.scene.models.isEmpty)
                    }
                    .padding(.horizontal)
                    .padding(.vertical, 8)
                    .background(Color.black.opacity(0.8))
                    
                    // Toolbar
                    ToolbarView(toolVM: toolVM, scene: $appState.canvasVM.scene)
                    
                    // Main content: MetalView + feature panel overlay
                    ZStack {
                        MetalView(
                            scene: $appState.canvasVM.scene,
                            strokes: $appState.canvasVM.strokes,
                            onTouch3D: handleTouch
                        )
                        
                        // Right panel with features
                        HStack {
                            Spacer()
                            featurePanel
                                .frame(width: 220)
                                .padding(.trailing, 8)
                        }
                    }
                }
            }
            .sheet(isPresented: $appState.showExport) {
                if let service = exportService {
                    ExportView(
                        exportVM: exportVM,
                        exportService: service,
                        scene: $appState.canvasVM.scene,
                        isPresented: $appState.showExport
                    )
                }
            }
            .onAppear {
                if let loadService = modelLoadService {
                    let box = loadService.createPrimitive(type: .box)
                    appState.canvasVM.scene.addModel(box)
                }
            }
        }
    }
    
    @ViewBuilder
    private var featurePanel: some View {
        switch appState.selectedMode {
        case .Sculpt:
            SculptModeView(toolVM: toolVM, scene: $appState.canvasVM.scene, strokes: $appState.canvasVM.strokes)
        case .CAD:
            CADModeView(toolVM: toolVM, scene: $appState.canvasVM.scene)
        case .Paint:
            PaintModeView(toolVM: toolVM, scene: $appState.canvasVM.scene, strokes: $appState.canvasVM.strokes)
        case .Hybrid:
            HybridModeView(toolVM: toolVM, scene: $appState.canvasVM.scene, strokes: $appState.canvasVM.strokes)
        case .Render:
            VStack {
                Text("Render Mode")
                    .font(.headline)
                    .foregroundColor(.white)
                Text("Iluminacion y preview final")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            .padding()
            .background(Color(.systemGray6).opacity(0.15))
            .cornerRadius(12)
        }
    }
    
    private func handleTouch(_ point: CGPoint) {
        // Basic touch handler for paint/sculpt
        if toolVM.currentMode == .Paint || toolVM.currentMode == .Sculpt {
            let ndcX = Float(point.x) / 100.0 - 0.5
            let ndcY = Float(point.y) / 100.0 - 0.5
            let worldPoint = SIMD3<Float>(ndcX * 2.0, ndcY * 2.0, 0)
            var stroke = BrushStroke(color: SIMD4<Float>(1, 1, 1, 1), radius: toolVM.brushSize, mode: .paint)
            stroke.addPoint(worldPoint)
            appState.canvasVM.strokes.append(stroke)
        }
    }
}